Build: push to GitHub and run the "Build APK" action, or open in Android Studio and Build > Build APK(s).
Replace app/src/main/assets/index.html to update your app.
